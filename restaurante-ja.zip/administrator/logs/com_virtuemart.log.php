#
#<?php die("Forbidden."); ?>

2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:08:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:24 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:08:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:08:27 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:28:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:28:42 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:29:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:29:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:29:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:30:19 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:32:47 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:32:57 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:32:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:32:57 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:32:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:32:57 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:32:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:32:57 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:32:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:32:57 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:32:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:32:57 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:33:10 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:33:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:33:10 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:33:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:33:10 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:33:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:33:10 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:33:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:33:10 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:33:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:33:10 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:33:13 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:33:23 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:33:42 ERROR vmError: Warning, the Safe Path is not configured yet. Use this link to the &lt;a href='http://localhost/restaurante-ja/administrator/index.php?option=com_virtuemart&amp;view=updatesmigration&amp;show_spwizard=1' &gt;setup wizard&lt;/a&gt;
2018-04-03 08:57:27 ERROR vmError: vendor Path/Url is not set correct :/var/www/html/restaurante-ja/images/virtuemart/vendor/
2018-04-03 08:57:27 ERROR vmError: forSale Path/Url is not set correct :
2018-04-03 08:58:09 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:58:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:58:09 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:58:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:58:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:58:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-03 08:59:03 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:03 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:26 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:26 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:44 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt2.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt2.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-03 08:59:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 08:59:49 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-03 09:00:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 09:00:09 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 09:00:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 09:00:09 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 09:00:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 09:00:09 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 09:00:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 09:00:13 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-03 09:00:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 09:00:13 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-03 09:00:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 09:00:13 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-03 09:00:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 09:00:31 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 09:00:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 09:00:31 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 09:00:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 09:00:31 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 09:00:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 09:00:31 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 09:02:23 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 09:02:23 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-03 09:02:23 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 09:02:23 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-03 09:02:23 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 09:02:23 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-03 09:02:23 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-03 09:02:23 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:33:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:33:01 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:36:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:36:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:39:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:39:17 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 07:40:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:40:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 07:41:20 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 07:41:20 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 07:41:20 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 08:32:59 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 08:32:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 08:32:59 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:44:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:44:55 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:04 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:11 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:11 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:14 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-10 08:45:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-10 08:45:21 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:00:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:00:28 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/category/student_hat_16.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt5.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat3.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/coat1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/skirt1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/shirt2.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/tshirt8.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:03:46 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:03:46 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:10:38 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:38 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:38 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:38 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:38 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:41 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:41 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:41 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:41 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:41 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:45 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:45 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:45 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:45 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:45 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:45 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:10:45 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:10:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:10:45 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat1.png
2018-04-17 08:10:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:10:45 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/hat2.png
2018-04-17 08:10:48 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:48 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:48 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:48 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:48 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:48 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:51 ERROR vmError: Attention product is parent, please delete the children first
2018-04-17 08:10:51 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:10:51 ERROR vmError: Couldnt create thumb, file not found /var/www/html/restaurante-ja/images/virtuemart/product/cart_logo.jpg
2018-04-17 08:54:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:54:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:54:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 08:59:03 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:05:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:05:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:05:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:09 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:10 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:33 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:42 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:45 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:06:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:06:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:07:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:07:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:07:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:07:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:08:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:08:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:08:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:08:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:08:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:08:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:09:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:09:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:09:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:09:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:09:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:09:31 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:10:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:10:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:10:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:10:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:39 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:39 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:12:39 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:12:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:52 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:52 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:12:52 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:12:55 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:12:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:12:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:15 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:20 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:20 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:20 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:22 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:27 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:30 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:30 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:30 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:13:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:13:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:14:51 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:14:51 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:14:51 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:14:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:14:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:14:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:02 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:02 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:15:02 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:15:38 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:15:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:15:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:15:44 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:18:23 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:18:24 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:19:12 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:19:12 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:19:12 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:19:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:19:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:19:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:20:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:20:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:20:58 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:21:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:21:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:21:13 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:21:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:21:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:21:14 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:22:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:22:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:22:32 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:22:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:22:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:22:36 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:23:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:40 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:40 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:23:40 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:23:41 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:23:59 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:24:21 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:24:49 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:25:18 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:25:37 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:26:00 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:26:01 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:26:16 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:26:17 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:26:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:26:57 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:28:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-17 09:28:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/producer.jpg
2018-04-17 09:28:04 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/manufacturer/manufacturer.jpg
2018-04-24 08:29:34 NO LANGUAGE LOADED  COM_VIRTUEMART &lt;pre&gt;#0  vmTrace() called at [/var/www/html/restaurante-ja/administrator/components/com_virtuemart/helpers/vmlanguage.php:268]
#1  vmLanguage::loadJLang() called at [/var/www/html/restaurante-ja/administrator/components/com_virtuemart/fields/vmloadlang.php:39]
#2  JFormFieldVmLoadLang-&gt;getInput() called at [/var/www/html/restaurante-ja/libraries/src/Form/FormField.php:973]
#3  Joomla\CMS\Form\FormField-&gt;renderField() called at [/var/www/html/restaurante-ja/layouts/joomla/edit/fieldset.php:47]
#4  include(/var/www/html/restaurante-ja/layouts/joomla/edit/fieldset.php) called at [/var/www/html/restaurante-ja/libraries/src/Layout/FileLayout.php:125]
#5  Joomla\CMS\Layout\FileLayout-&gt;render() called at [/var/www/html/restaurante-ja/libraries/src/Layout/LayoutHelper.php:73]
#6  Joomla\CMS\Layout\LayoutHelper::render() called at [/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/edit.php:229]
#7  include(/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/edit.php) called at [/var/www/html/restaurante-ja/libraries/src/MVC/View/HtmlView.php:695]
#8  Joomla\CMS\MVC\View\HtmlView-&gt;loadTemplate() called at [/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/modal.php:20]
#9  include(/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/modal.php) called at [/var/www/html/restaurante-ja/libraries/src/MVC/View/HtmlView.php:695]
&lt;/pre&gt;
2018-04-24 08:29:34 NO LANGUAGE LOADED  COM_VIRTUEMART_CONFIG &lt;pre&gt;#0  vmTrace() called at [/var/www/html/restaurante-ja/administrator/components/com_virtuemart/helpers/vmlanguage.php:268]
#1  vmLanguage::loadJLang() called at [/var/www/html/restaurante-ja/administrator/components/com_virtuemart/fields/vmloadlang.php:39]
#2  JFormFieldVmLoadLang-&gt;getInput() called at [/var/www/html/restaurante-ja/libraries/src/Form/FormField.php:973]
#3  Joomla\CMS\Form\FormField-&gt;renderField() called at [/var/www/html/restaurante-ja/layouts/joomla/edit/fieldset.php:47]
#4  include(/var/www/html/restaurante-ja/layouts/joomla/edit/fieldset.php) called at [/var/www/html/restaurante-ja/libraries/src/Layout/FileLayout.php:125]
#5  Joomla\CMS\Layout\FileLayout-&gt;render() called at [/var/www/html/restaurante-ja/libraries/src/Layout/LayoutHelper.php:73]
#6  Joomla\CMS\Layout\LayoutHelper::render() called at [/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/edit.php:229]
#7  include(/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/edit.php) called at [/var/www/html/restaurante-ja/libraries/src/MVC/View/HtmlView.php:695]
#8  Joomla\CMS\MVC\View\HtmlView-&gt;loadTemplate() called at [/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/modal.php:20]
#9  include(/var/www/html/restaurante-ja/administrator/components/com_modules/views/module/tmpl/modal.php) called at [/var/www/html/restaurante-ja/libraries/src/MVC/View/HtmlView.php:695]
&lt;/pre&gt;
2018-04-24 08:33:53 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-24 08:34:28 ERROR vmError: File not found /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-24 08:36:15 ERROR vmError: Access Forbidden allowUserRegistration in joomla disabled
2018-04-24 08:51:02 ERROR vmError: Archivo no encontrado /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-24 09:01:13 ERROR vmError: Archivo no encontrado /var/www/html/restaurante-ja/images/virtuemart/vendor/vendor.gif
2018-04-30 08:38:09 ERROR vmError: TableOrderstates ¡Código de estado de pedido falta en registro! No se puede guardar el registro sin Código de estado de pedido.
2018-04-30 08:38:16 ERROR vmError: TableOrderstates ¡Nombre de estado de pedido falta en registro! No se puede guardar el registro sin Nombre de estado de pedido.